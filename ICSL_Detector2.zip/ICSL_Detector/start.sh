# you must have root permission!! #

############### run.py ################

apt install python3-pip
pip3 install PyMySQL

########## Basic install #################

sudo apt-get install vim
sudo apt-get install git
sudo apt install make  
sudo apt install gcc

############## telegraf install ###########################

sudo wget -qO- https://repos.influxdata.com/influxdb.key | sudo apt-key add -
source /etc/lsb-release
echo "deb https://repos.influxdata.com/${DISTRIB_ID,,} ${DISTRIB_CODENAME} stable" | sudo tee /etc/apt/sources.list.d/influxdb.list
sudo apt-get update && sudo apt-get install telegraf
sudo systemctl start telegraf

############## go install ###############################

sudo add-apt-repository ppa:longsleep/golang-backports
sudo apt-get update
sudo apt-get install golang-go

############## telegraf github###########################

git clone https://github.com/influxdata/telegraf.git
rm ./plugins/inputs/mysql/mysql.go
mv ./mysql.go ./telegraf/plugins/inputs/mysql
cd telegraf
sudo make # 오래걸림
#################mysql install #########################

sudo apt-get install libmysqlclient-dev
sudo apt-get update
sudo apt-get install mysql-server
sudo ufw allow mysql
sudo systemctl start mysql
sudo systemctl enable mysql

cd ..

cd pcm-icsl/pcm-icsl/
make
cp pcm-icsl.x ../../CSCA_Detection/
echo 0 > /proc/sys/kernel/nmi_watchdog
echo 'kernel.nmi_watchdog=0' >> /etc/sysctl.conf
modprobe msr
sudo apt-get install python3-pip
sudo pip3 install tensorflow
pip3 install PyMySQL
